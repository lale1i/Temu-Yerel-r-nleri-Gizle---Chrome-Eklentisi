(() => {
  "use strict";

  /**
   * Temu Yabancı Ürünleri Öne Al
   *
   * Yaklaşım: GİZLEME YOK. Ürünler flex grid içinde CSS "order" ile
   * yeniden sıralanır. Yabancı (Yerel/Local rozeti olmayan) ürünler öne,
   * yerel ürünler en arkaya atılır.
   *
   * ÖNEMLİ: Temu React ile render edildiği için, bir kartın stili
   * (fiyat/satış sayacı güncellendiğinde) React tarafından yeniden
   * yazılabilir ve doğrudan element.style üzerinden verdiğimiz "order"
   * değeri silinebilir. Bunu önlemek için:
   *   1) Sıralamayı inline style ile DEĞİL, kendi eklediğimiz bir
   *      data-* attribute + kendi <style> kuralımızla uyguluyoruz.
   *      React bu attribute'u yönetmediği için silmiyor.
   *   2) Ek güvenlik olarak süresiz (sayfa ömrü boyunca) hafif bir
   *      periyodik yeniden kontrol döngüsü çalıştırıyoruz.
   */

  const CARD = 'div[role="group"]';
  const ORDER_ATTR = "data-temu-order";
  const DEBOUNCE_MS = 200;
  const SAFETY_INTERVAL_MS = 1200;

  let debounceTimer = null;
  let lastHref = location.href;

  // React'ın silemeyeceği, kendi stylesheet'imizden gelen sıralama kuralı
  const style = document.createElement("style");
  style.textContent = `
    [${ORDER_ATTR}="foreign"] { order: 0 !important; }
    [${ORDER_ATTR}="local"]   { order: 999999 !important; }
  `;
  (document.head || document.documentElement).appendChild(style);

  function isLocalCard(card) {
    for (const span of card.querySelectorAll("span")) {
      const t = span.textContent.trim();
      if (t === "Yerel" || t === "Local") return true;
    }
    return false;
  }

  /** Kartın ait olduğu flex item'ı (flex konteynerin doğrudan çocuğu) bul. */
  function getFlexItem(card) {
    let el = card;
    while (el && el.parentElement && el.parentElement !== document.body) {
      const parent = el.parentElement;
      let display = "";
      try {
        display = getComputedStyle(parent).display;
      } catch {
        display = "";
      }
      if (display === "flex" || display === "inline-flex") return el;
      el = parent;
    }
    return null;
  }

  function applyOrder(item, value) {
    if (item.getAttribute(ORDER_ATTR) === value) return;
    item.setAttribute(ORDER_ATTR, value);
  }

  /**
   * Bir flex item içinde en az bir yabancı kart varsa → öne.
   * Tüm kartları yerel ise → arkaya.
   */
  function scoreFlexItem(item) {
    const cards = item.querySelectorAll(CARD);
    if (cards.length === 0) return;

    let anyForeign = false;
    for (const c of cards) {
      if (!isLocalCard(c)) {
        anyForeign = true;
        break;
      }
    }
    applyOrder(item, anyForeign ? "foreign" : "local");
  }

  function scanAll() {
    const cards = document.querySelectorAll(CARD);
    const seen = new Set();
    for (const card of cards) {
      const item = getFlexItem(card);
      if (!item || seen.has(item)) continue;
      seen.add(item);
      scoreFlexItem(item);
    }
  }

  function scheduleScan() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(scanAll, DEBOUNCE_MS);
  }

  function processAdded(node) {
    let cards = [];
    if (node.matches?.(CARD)) cards.push(node);
    if (node.querySelectorAll) cards.push(...node.querySelectorAll(CARD));

    const seen = new Set();
    for (const card of cards) {
      const item = getFlexItem(card);
      if (!item || seen.has(item)) continue;
      seen.add(item);
      scoreFlexItem(item);
    }
  }

  function onMutations(mutations) {
    let touched = false;
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        processAdded(node);
        touched = true;
      }
      // Rozet sonradan (lazy) gelebilir veya metin güncellenebilir
      if (m.type === "characterData") touched = true;
    }
    if (touched) scheduleScan();
  }

  function onUrlChange() {
    if (location.href === lastHref) return;
    lastHref = location.href;
    scanAll();
    [400, 1000, 2000].forEach((ms) => setTimeout(scanAll, ms));
  }

  function init() {
    if (!document.body) {
      requestAnimationFrame(init);
      return;
    }

    scanAll();

    new MutationObserver(onMutations).observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
    });

    window.addEventListener("popstate", onUrlChange);
    setInterval(onUrlChange, 1000);

    // İlk yükleme / hydrate için birkaç yeniden tarama
    [300, 800, 1500, 3000, 5000, 8000].forEach((ms) => setTimeout(scanAll, ms));

    // Sayfa ömrü boyunca güvenlik ağı: React'ın olası style/attribute
    // sıfırlamalarına ve gözden kaçan güncellemelere karşı sürekli kontrol
    setInterval(scanAll, SAFETY_INTERVAL_MS);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
